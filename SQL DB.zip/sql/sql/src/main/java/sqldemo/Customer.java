package sqldemo;
import javax.persistence.*;

@Entity
@Table(name = "customers")
public class Customer {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int CUS_ID;
	     
	    private String CUS_NAME;

		public int getCUS_ID() {
			return CUS_ID;
		}

		public void setCUS_ID(int cUS_ID) {
			CUS_ID = cUS_ID;
		}

		public String getCUS_NAME() {
			return CUS_NAME;
		}

		public void setCUS_NAME(String cUS_NAME) {
			CUS_NAME = cUS_NAME;
		}

		@Override
		public String toString() {
			return "Customer [CUS_ID=" + CUS_ID + ", CUS_NAME=" + CUS_NAME + "]";
		}
	    
}
