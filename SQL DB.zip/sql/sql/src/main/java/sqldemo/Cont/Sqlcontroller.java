package sqldemo.Cont;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import sqldemo.Customer;
import sqldemo.CustomerRepository;

@Controller
public class Sqlcontroller {
	 @Autowired
	    private CustomerRepository customerRepo;
	     
	    @GetMapping("/customers")
	    public String listAll(Model model) {
	        List listCustomers = (List) customerRepo.findAll();
	        model.addAttribute("listCustomers", listCustomers);
	         
	        return "customers";
	    }

}
