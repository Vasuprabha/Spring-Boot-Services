package htmlDemo.conrt;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/login/")
public class Democontroller {
@RequestMapping(value="Htmldemo", method = RequestMethod.GET)
public ResponseEntity<?>Htmldemo(@RequestParam Map<String, String> input )throws Exception{
  String uname=input.get("userName");
  String upass=input.get("password");

 String userName = "Mithra"	;
 String password = "1805";
 if(userName.equals(uname) && password.equals(upass))
 {
	 input.put("Staus", "Login Sucessfully");
 }
 else
 {
	 input.put("Staus", "Login Failed");

 }
 return new ResponseEntity<>(input, HttpStatus.OK);
 
 
 
 
 
 
 
 
	
	
	
	
}
}
