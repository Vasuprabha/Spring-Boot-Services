package com.files;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication(scanBasePackages=("com.files"))

public class FilePropsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilePropsApplication.class, args);
	}

}
