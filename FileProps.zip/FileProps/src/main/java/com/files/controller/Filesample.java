package com.files.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.files.controller.Files.Fileservice;
@RestController
@RequestMapping("/api/")
public class Filesample {
	
	
		@Autowired
		Environment env;
	
		@Autowired
		Fileservice obj;
		@RequestMapping(value = "testAPI", method = RequestMethod.GET)
		public ResponseEntity<?> testAPI(@RequestParam String op) {
		int operation = Integer.parseInt(env.getProperty("n1"));
		int operation1 = Integer.parseInt(env.getProperty("n2"));
		int ans=0;
		switch (op) {
		case "add":
		ans = obj.add(operation, operation1);
		break;
		case "sub":
		ans = obj.sub(operation, operation1);
		break;
		case "multiply":
		ans = obj.multiplication(operation, operation1);
		break;
		case "division":

		ans = obj.division(operation, operation1);
		break;
		}
		return new ResponseEntity<>(ans, HttpStatus.OK);
		}
	}
	




