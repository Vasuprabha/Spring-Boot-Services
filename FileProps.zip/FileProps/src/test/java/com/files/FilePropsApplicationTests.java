package com.files;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilePropsApplicationTests {

	@Test
	void contextLoads() {
	}

}
